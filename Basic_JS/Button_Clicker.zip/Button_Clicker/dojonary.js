// function example(element) {
//     console.log("element clicked", element);
// }

function turnOff(element) {
    element.innerText = "Log Off";
}


function hide(element) {
    element.remove();
}
